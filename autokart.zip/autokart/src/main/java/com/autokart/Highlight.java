package com.autokart;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

/**
 * Picks the block for the rail and marks it with red dust.
 * The pick: every spot around the closest player where a rail fits and the block can be reached,
 * scored with the explosion damage formula: damage to the enemy minus (selfWeight * damage to you).
 * Armor, enchantments and effects are not counted.
 * All of the drawing is in show(), so it is easy to swap for a real outline later.
 */
final class Highlight {
    // search area around the enemy (blocks)
    private static final int SIDE = 3;
    private static final int DOWN = 3;
    private static final int UP = 2;
    // a minecart on a flat rail stands a bit above the rail block
    private static final double CART_Y = 0.0625;

    private Highlight() {
    }

    /** the block to put the rail on, or null if nothing is worth it */
    static BlockPos find(MinecraftClient mc, ClientPlayerEntity me, Config cfg) {
        World world = mc.world;
        Entity target = null;
        double nearest = cfg.targetRange * cfg.targetRange;
        for (PlayerEntity other : world.getPlayers()) {
            if (other == me || other.isSpectator() || !other.isAlive()) {
                continue;
            }
            double d = me.squaredDistanceTo(other);
            if (d < nearest) {
                nearest = d;
                target = other;
            }
        }
        // TEST: Wardens count as targets too
        if (cfg.testWarden) {
            for (Entity other : world.getOtherEntities(me, me.getBoundingBox().expand(cfg.targetRange),
                    e -> e.getType() == EntityType.WARDEN && e.isAlive())) {
                double d = me.squaredDistanceTo(other);
                if (d < nearest) {
                    nearest = d;
                    target = other;
                }
            }
        }
        if (target == null) {
            return null;
        }

        Vec3d eye = me.getEyePos();
        BlockPos around = target.getBlockPos();
        BlockPos best = null;
        double bestScore = 0;
        for (int dx = -SIDE; dx <= SIDE; dx++) {
            for (int dz = -SIDE; dz <= SIDE; dz++) {
                for (int dy = -DOWN; dy <= UP; dy++) {
                    BlockPos cell = around.add(dx, dy, dz);
                    if (!railFits(world, cell)) {
                        continue;
                    }
                    BlockPos support = cell.down();
                    if (!inReach(eye, support, cfg.reach)) {
                        continue;
                    }
                    Vec3d boom = new Vec3d(cell.getX() + 0.5, cell.getY() + CART_Y, cell.getZ() + 0.5);
                    double enemy = damage(world, boom, target, cfg.cartPower);
                    if (enemy <= 0) {
                        continue;
                    }
                    double score = enemy - cfg.selfWeight * damage(world, boom, me, cfg.cartPower);
                    // only spots where the enemy takes more than you do (weighted)
                    if (score > bestScore) {
                        bestScore = score;
                        best = support;
                    }
                }
            }
        }
        return best;
    }

    private static boolean railFits(World world, BlockPos cell) {
        BlockState state = world.getBlockState(cell);
        if (!state.isAir() && !state.isReplaceable()) {
            return false;
        }
        if (!world.getFluidState(cell).isEmpty()) {
            return false;
        }
        BlockPos support = cell.down();
        return world.getBlockState(support).isSideSolidFullSquare(world, support, Direction.UP);
    }

    // the closest point of the top face of the block has to be inside your reach
    private static boolean inReach(Vec3d eye, BlockPos support, double reach) {
        double px = Math.max(support.getX(), Math.min(support.getX() + 1.0, eye.x));
        double pz = Math.max(support.getZ(), Math.min(support.getZ() + 1.0, eye.z));
        double py = support.getY() + 1.0;
        return eye.squaredDistanceTo(px, py, pz) <= reach * reach;
    }

    /** explosion damage in half hearts, same formula as the game (without armor) */
    private static double damage(World world, Vec3d center, Entity entity, double power) {
        double radius = power * 2.0;
        double dist = Math.sqrt(entity.squaredDistanceTo(center));
        if (dist >= radius) {
            return 0;
        }
        double a = (1.0 - dist / radius) * exposure(world, center, entity);
        if (a <= 0) {
            return 0;
        }
        return Math.floor((a * a + a) / 2.0 * 7.0 * radius + 1.0);
    }

    /** share of the body (7 points) that the blast can see, blocks in between take it away */
    private static double exposure(World world, Vec3d from, Entity entity) {
        Box box = entity.getBoundingBox();
        double cx = (box.minX + box.maxX) / 2.0;
        double cz = (box.minZ + box.maxZ) / 2.0;
        double w = (box.maxX - box.minX) * 0.4;
        double d = (box.maxZ - box.minZ) * 0.4;
        double h = box.maxY - box.minY;
        double mid = box.minY + h * 0.5;
        int seen = 0;
        double[] levels = {0.1, 0.5, 0.9};
        for (double f : levels) {
            if (sees(world, from, new Vec3d(cx, box.minY + h * f, cz), entity)) {
                seen++;
            }
        }
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sz = -1; sz <= 1; sz += 2) {
                if (sees(world, from, new Vec3d(cx + sx * w, mid, cz + sz * d), entity)) {
                    seen++;
                }
            }
        }
        return seen / 7.0;
    }

    private static boolean sees(World world, Vec3d from, Vec3d to, Entity entity) {
        RaycastContext ctx = new RaycastContext(from, to, RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE, entity);
        return world.raycast(ctx).getType() == HitResult.Type.MISS;
    }

    /** red frame and a dot in the middle on the top face of the block */
    static void show(ClientWorld world, BlockPos support) {
        DustParticleEffect red = new DustParticleEffect(DustParticleEffect.RED, 0.8f);
        double y = support.getY() + 1.02;
        double x0 = support.getX();
        double z0 = support.getZ();
        for (int i = 0; i <= 4; i++) {
            double t = i / 4.0;
            dot(world, red, x0 + t, y, z0);
            dot(world, red, x0 + t, y, z0 + 1);
            if (i > 0 && i < 4) {
                dot(world, red, x0, y, z0 + t);
                dot(world, red, x0 + 1, y, z0 + t);
            }
        }
        dot(world, red, x0 + 0.5, y, z0 + 0.5);
    }

    private static void dot(ClientWorld world, DustParticleEffect effect, double x, double y, double z) {
        world.addImportantParticleClient(effect, x, y, z, 0, 0, 0);
    }
}
