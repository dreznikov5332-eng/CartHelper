package com.autokart;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** config/autokart.json */
public class Config {
    public static final int MAX_STEPS = 6;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /** one item of the chain */
    public static class Step {
        public Pick item = Pick.RAIL;
        /**
         * false: a new step of the chain.
         * true: a spare for the previous item, used when the previous one is not in the hotbar.
         */
        public boolean orPrev;

        public Step() {
        }

        public Step(Pick item, boolean orPrev) {
            this.item = item;
            this.orPrev = orPrev;
        }
    }

    /** whole mod on/off */
    public boolean enabled = true;
    /** red marker on the block for the rail */
    public boolean highlight = true;
    /** switch items by itself after each action of the chain */
    public boolean autoSwitch = true;
    /** how far (blocks) to look for a player to mark */
    public double targetRange = 12.0;
    /** how far you can place blocks (survival is 4.5) */
    public double reach = 4.5;
    /** explosion power of the cart, 4 = standing TNT minecart */
    public double cartPower = 4.0;
    /** 0 = ignore damage to you, 1 = your damage counts as much as the enemy's, more = be careful */
    public double selfWeight = 1.0;
    /** the chain: after the action with an item the mod takes the next one */
    public List<Step> sequence = defaultSequence();

    private static List<Step> defaultSequence() {
        List<Step> list = new ArrayList<>();
        list.add(new Step(Pick.RAIL, false));
        list.add(new Step(Pick.TNT_MINECART, false));
        list.add(new Step(Pick.BOW, false));
        list.add(new Step(Pick.FLINT_AND_STEEL, true));
        list.add(new Step(Pick.CROSSBOW, true));
        return list;
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("autokart.json");
    }

    public static Config load() {
        Path p = path();
        if (Files.exists(p)) {
            try {
                Config c = GSON.fromJson(Files.readString(p), Config.class);
                if (c != null) {
                    c.fix();
                    c.save();
                    return c;
                }
            } catch (Exception e) {
                System.out.println("[AutoKart] bad config, using defaults: " + e);
            }
        }
        Config c = new Config();
        c.save();
        return c;
    }

    // a typo in the json gives null entries, drop them
    private void fix() {
        List<Step> clean = new ArrayList<>();
        if (sequence != null) {
            for (Step s : sequence) {
                if (s != null && s.item != null && clean.size() < MAX_STEPS) {
                    clean.add(s);
                }
            }
        }
        sequence = clean;
        normalize();
        targetRange = Math.max(2.0, Math.min(64.0, targetRange));
        reach = Math.max(1.0, Math.min(8.0, reach));
        cartPower = Math.max(1.0, Math.min(12.0, cartPower));
        selfWeight = Math.max(0.0, Math.min(5.0, selfWeight));
    }

    /** the first item can not be a spare for something */
    public void normalize() {
        if (!sequence.isEmpty()) {
            sequence.get(0).orPrev = false;
        }
    }

    public void save() {
        try {
            Files.writeString(path(), GSON.toJson(this));
        } catch (IOException e) {
            System.out.println("[AutoKart] could not save config: " + e);
        }
    }
}
