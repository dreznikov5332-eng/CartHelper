package com.carthelper;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

// config/carthelper.json
public class Config {
    public static final int MAX_STEPS = 6;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    // один предмет цепочки
    public static class Step {
        public Pick item = Pick.RAIL;
        // true = запасной для предыдущего (если того нет в хотбаре)
        public boolean orPrev;

        public Step() {
        }

        public Step(Pick item, boolean orPrev) {
            this.item = item;
            this.orPrev = orPrev;
        }
    }

    public boolean enabled = true;
    public boolean highlight = true;
    public boolean autoSwitch = true;
    public double targetRange = 12.0;
    // для тестов: вардены тоже цели, потом выключить
    public boolean testWarden = true;
    public double reach = 4.5;
    // сила взрыва вагонетки
    public double cartPower = 4.0;
    // 0 = урон по себе не считаем, 1 = как по врагу, больше = осторожнее
    public double selfWeight = 1.0;
    public List<Step> sequence = defaultSequence();

    private static List<Step> defaultSequence() {
        List<Step> list = new ArrayList<>();
        list.add(new Step(Pick.RAIL, false));
        list.add(new Step(Pick.TNT_MINECART, false));
        list.add(new Step(Pick.BOW, false));
        list.add(new Step(Pick.FLINT_AND_STEEL, true));
        list.add(new Step(Pick.CROSSBOW, true));
        return list;
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("carthelper.json");
    }

    public static Config load() {
        Path p = path();
        if (Files.exists(p)) {
            try {
                Config c = GSON.fromJson(Files.readString(p), Config.class);
                if (c != null) {
                    c.fix();
                    c.save();
                    return c;
                }
            } catch (Exception e) {
                System.out.println("[CartHelper] плохой конфиг, беру стандартный: " + e);
            }
        }
        Config c = new Config();
        c.save();
        return c;
    }

    // опечатка в json даёт null
    private void fix() {
        List<Step> clean = new ArrayList<>();
        if (sequence != null) {
            for (Step s : sequence) {
                if (s != null && s.item != null && clean.size() < MAX_STEPS) {
                    clean.add(s);
                }
            }
        }
        sequence = clean;
        normalize();
        targetRange = Math.max(2.0, Math.min(64.0, targetRange));
        reach = Math.max(1.0, Math.min(8.0, reach));
        cartPower = Math.max(1.0, Math.min(12.0, cartPower));
        selfWeight = Math.max(0.0, Math.min(5.0, selfWeight));
    }

    public void normalize() {
        if (!sequence.isEmpty()) {
            sequence.get(0).orPrev = false;
        }
    }

    public void save() {
        try {
            Files.writeString(path(), GSON.toJson(this));
        } catch (IOException e) {
            System.out.println("[CartHelper] не сохранился конфиг: " + e);
        }
    }
}
