package com.carthelper;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

// меню: выключатели и цепочка предметов, всё сохраняется сразу
public final class KartScreen extends Screen {
    private static final int PANEL_W = 360;
    private static final int PANEL_TOP = 4;
    private static final int PANEL_BOTTOM = 264;
    private static final int ROW_W = 288;
    private static final int LIST_TOP = 136;
    private static final int ROW = 20;
    private static final int HELP_WIDTH = 320;

    private static final int PANEL = 0xE6101018;
    private static final int BORDER = 0xFF5A1D1D;
    private static final int ACCENT = 0xFFD83A3A;
    private static final int ACCENT_SPARE = 0xFFE0B040;
    private static final int TITLE_TOP = 0xFF8E1F1F;
    private static final int TITLE_BOTTOM = 0xFF4D1111;
    private static final int CARD = 0x2AFFFFFF;
    private static final int STRIPE = 0x30000000;
    private static final int SLOT = 0x80000000;
    private static final int LABEL = 0xFFC8C8D8;

    private static final Map<String, String[]> HELP = Map.of(
            "mod", new String[]{"Мод",
                    "Главный выключатель. Когда мод выключен, не работают ни подсветка, ни автовыбор предметов."},
            "highlight", new String[]{"Подсветка",
                    "Красные точки на верхней грани блока, на который лучше поставить рельсу. Мод следит за ближайшим "
                            + "игроком и выбирает место, до которого ты достаёшь и где взрыв ударит по нему сильнее, чем по тебе. "
                            + "Подсветку можно быстро включать и выключать клавишей H."},
            "switch", new String[]{"Автовыбор",
                    "Мод сам берёт в руку следующий предмет из списка, когда ты закончил действие с текущим: поставил "
                            + "рельсу или вагонетку, сделал выстрел из лука или арбалета, использовал огниво. Когда последний "
                            + "предмет использован, цепочка заканчивается и ждёт следующего раза. Берутся только предметы из хотбара."},
            "caution", new String[]{"Осторожность (вред себе)",
                    "Насколько важно самому не получить урон. 0: урон по тебе не считается. 1: твой урон считается наравне "
                            + "с уроном противника. Больше: мод выбирает места безопаснее, даже если противнику достанется меньше. "
                            + "Если везде тебе достаётся не меньше, чем ему, подсветки нет."},
            "list", new String[]{"Порядок предметов",
                    "После каждого действия мод берёт следующий предмет. Пример: Лук, Рельсы, Вагонетка. Стреляешь, "
                            + "берутся рельсы, ставишь рельсы, берётся вагонетка, ставишь, и стрела взрывает её. Кнопка слева в "
                            + "строке: «затем» значит новый шаг, «или» значит запасной предмет для предыдущего (берётся, если "
                            + "основного нет в хотбаре). «<» и «>» меняют предмет, «^» и «v» двигают, «x» удаляет, "
                            + "«+ Добавить» добавляет в конец."}
    );

    private final Config config;
    // какая подсказка открыта
    private String help;

    public KartScreen(Config config) {
        super(Text.literal("CartHelper: настройки"));
        this.config = config;
    }

    private int rowsX() {
        return this.width / 2 - ROW_W / 2;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int xs = cx - 177;

        addDrawableChild(ButtonWidget.builder(Text.literal("Готово"), btn -> close())
                .dimensions(cx + 104, 6, 70, 16).build());

        addDrawableChild(switchButton(xs, 41, "Мод", config.enabled, () -> config.enabled = !config.enabled));
        addDrawableChild(arrow(xs + 98, 41, 20, "mod"));
        addDrawableChild(switchButton(xs + 119, 41, "Подсветка", config.highlight, () -> config.highlight = !config.highlight));
        addDrawableChild(arrow(xs + 217, 41, 20, "highlight"));
        addDrawableChild(switchButton(xs + 238, 41, "Автовыбор", config.autoSwitch, () -> config.autoSwitch = !config.autoSwitch));
        addDrawableChild(arrow(xs + 336, 41, 20, "switch"));

        addDrawableChild(small("-", cx - 115, 84, 18, () -> config.selfWeight = round1(Math.max(0, config.selfWeight - 0.5))));
        addDrawableChild(small("+", cx + 97, 84, 18, () -> config.selfWeight = round1(Math.min(5, config.selfWeight + 0.5))));
        addDrawableChild(arrow(cx + 119, 84, 18, "caution"));

        List<Config.Step> list = config.sequence;
        int x0 = rowsX();
        ButtonWidget add = ButtonWidget.builder(Text.literal("+ Добавить"), btn -> {
            list.add(new Config.Step(nextUnused(list), false));
            changed();
        }).dimensions(x0 + 148, 114, 108, 18).build();
        add.active = help == null && list.size() < Config.MAX_STEPS;
        addDrawableChild(add);
        addDrawableChild(arrow(x0 + 270, 114, 18, "list"));

        if (help == null) {
            for (int i = 0; i < list.size(); i++) {
                final int idx = i;
                final Config.Step step = list.get(i);
                int y = LIST_TOP + i * ROW;
                if (i > 0) {
                    Text link = step.orPrev
                            ? Text.literal("или").formatted(Formatting.YELLOW)
                            : Text.literal("затем").formatted(Formatting.AQUA);
                    addDrawableChild(smallText(link, x0, y, 44, () -> step.orPrev = !step.orPrev));
                }
                addDrawableChild(small("<", x0 + 46, y, 20, () -> step.item = step.item.step(-1)));
                // тут пустое место под иконку, рисуется в render
                addDrawableChild(ButtonWidget.builder(step.item.label(), btn -> {
                    step.item = step.item.step(1);
                    changed();
                }).dimensions(x0 + 90, y, 110, 18).build());
                addDrawableChild(small(">", x0 + 202, y, 20, () -> step.item = step.item.step(1)));
                addDrawableChild(small("^", x0 + 224, y, 20, () -> {
                    if (idx > 0) Collections.swap(list, idx, idx - 1);
                }));
                addDrawableChild(small("v", x0 + 246, y, 20, () -> {
                    if (idx < list.size() - 1) Collections.swap(list, idx, idx + 1);
                }));
                addDrawableChild(small("x", x0 + 268, y, 20, () -> list.remove(idx)));
            }
        }
    }

    private static Pick nextUnused(List<Config.Step> list) {
        for (Pick p : Pick.values()) {
            boolean used = false;
            for (Config.Step s : list) {
                if (s.item == p) {
                    used = true;
                }
            }
            if (!used) {
                return p;
            }
        }
        return Pick.values()[0];
    }

    private ButtonWidget arrow(int x, int y, int h, String key) {
        return ButtonWidget.builder(Text.literal(key.equals(help) ? "v" : ">"), btn -> {
            help = key.equals(help) ? null : key;
            clearAndInit();
        }).dimensions(x, y, 18, h).build();
    }

    private ButtonWidget switchButton(int x, int y, String name, boolean on, Runnable flip) {
        Text label = Text.literal(name + ": ")
                .append(Text.literal(on ? "вкл" : "выкл").formatted(on ? Formatting.GREEN : Formatting.RED));
        return ButtonWidget.builder(label, btn -> {
            flip.run();
            config.save();
            clearAndInit();
        }).dimensions(x, y, 96, 20).build();
    }

    private ButtonWidget small(String text, int x, int y, int w, Runnable action) {
        return smallText(Text.literal(text), x, y, w, action);
    }

    private ButtonWidget smallText(Text text, int x, int y, int w, Runnable action) {
        return ButtonWidget.builder(text, btn -> {
            action.run();
            changed();
        }).dimensions(x, y, w, 18).build();
    }

    private static double round1(double v) {
        return Math.round(v * 10.0) / 10.0;
    }

    private void changed() {
        config.normalize();
        config.save();
        clearAndInit();
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.renderBackground(ctx, mouseX, mouseY, delta);
        int cx = this.width / 2;
        int left = cx - PANEL_W / 2;
        int right = cx + PANEL_W / 2;

        ctx.fill(left - 1, PANEL_TOP - 1, right + 1, PANEL_BOTTOM + 1, BORDER);
        ctx.fill(left, PANEL_TOP, right, PANEL_BOTTOM, PANEL);

        // шапка, градиент из линий по 1 пикселю
        for (int y = PANEL_TOP; y < 24; y++) {
            ctx.fill(left, y, right, y + 1, mix(TITLE_TOP, TITLE_BOTTOM, (y - PANEL_TOP) / 19.0f));
        }
        ctx.fill(left, 24, right, 25, ACCENT);

        card(ctx, left, right, 28, 66);
        card(ctx, left, right, 70, 108);
        card(ctx, left, right, 112, PANEL_BOTTOM - 4);

        if (help == null) {
            int x0 = rowsX();
            List<Config.Step> list = config.sequence;
            for (int i = 0; i < list.size(); i++) {
                int y = LIST_TOP + i * ROW;
                if (i % 2 == 0) {
                    ctx.fill(x0 - 20, y - 1, x0 + ROW_W + 4, y + ROW - 1, STRIPE);
                }
                // красная полоска = шаг, жёлтая = запасной
                boolean spare = i > 0 && list.get(i).orPrev;
                ctx.fill(x0 - 6, y, x0 - 3, y + 18, spare ? ACCENT_SPARE : ACCENT);
                ctx.fill(x0 + 68, y, x0 + 88, y + 18, SLOT);
            }
        }
    }

    private void card(DrawContext ctx, int left, int right, int top, int bottom) {
        ctx.fill(left + 4, top, right - 4, bottom, CARD);
    }

    private void section(DrawContext ctx, int left, int y, String text) {
        ctx.fill(left + 8, y, left + 10, y + 8, ACCENT);
        ctx.drawTextWithShadow(this.textRenderer, Text.literal(text), left + 14, y, LABEL);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        int cx = this.width / 2;
        int left = cx - PANEL_W / 2;

        ctx.drawTextWithShadow(this.textRenderer, Text.literal("CartHelper").formatted(Formatting.GOLD, Formatting.BOLD),
                left + 10, 10, 0xFFFFFFFF);
        ctx.drawTextWithShadow(this.textRenderer, Text.literal("настройки, всё сохраняется сразу"),
                left + 64, 10, 0xFFE0C0C0);

        section(ctx, left, 31, "ОСНОВНОЕ");
        section(ctx, left, 73, "ВЫБОР БЛОКА ДЛЯ РЕЛЬСЫ");
        ctx.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Осторожность: " + config.selfWeight), cx, 89, 0xFFFFE08A);
        section(ctx, left, 118, "ПОРЯДОК ПРЕДМЕТОВ");

        if (help != null) {
            drawHelp(ctx, cx);
            return;
        }

        int x0 = rowsX();
        List<Config.Step> list = config.sequence;
        for (int i = 0; i < list.size(); i++) {
            int y = LIST_TOP + i * ROW;
            ctx.drawTextWithShadow(this.textRenderer, Text.literal(String.valueOf(i + 1)), x0 - 17, y + 5, 0xFF9090A0);
            ctx.drawItem(list.get(i).item.stack(), x0 + 70, y + 1);
        }
        if (list.isEmpty()) {
            ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal("Список пуст: нажми «+ Добавить»"),
                    cx, LIST_TOP + 8, 0xFFFFFF55);
        }
    }

    private void drawHelp(DrawContext ctx, int cx) {
        String[] h = HELP.get(help);
        if (h == null) {
            return;
        }
        int maxW = Math.min(this.width - 40, HELP_WIDTH);
        int x = cx - maxW / 2;
        List<String> lines = wrap(h[1], maxW);
        int boxTop = LIST_TOP - 2;
        int boxBottom = LIST_TOP + 14 + lines.size() * 11 + 22;
        ctx.fill(x - 10, boxTop, x + maxW + 8, boxBottom, 0x70000000);
        ctx.fill(x - 10, boxTop, x - 8, boxBottom, ACCENT);

        int y = LIST_TOP + 2;
        ctx.drawTextWithShadow(this.textRenderer, Text.literal(h[0]), x, y, 0xFFFFE08A);
        y += 14;
        for (String line : lines) {
            ctx.drawTextWithShadow(this.textRenderer, Text.literal(line), x, y, 0xFFFFFFFF);
            y += 11;
        }
        ctx.drawTextWithShadow(this.textRenderer, Text.literal("Нажми стрелку ещё раз, чтобы закрыть."),
                x, y + 6, 0xFF9090A0);
    }

    private List<String> wrap(String text, int maxW) {
        List<String> out = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : text.split(" ")) {
            String next = line.length() == 0 ? word : line + " " + word;
            if (line.length() > 0 && this.textRenderer.getWidth(next) > maxW) {
                out.add(line.toString());
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(next);
            }
        }
        if (line.length() > 0) {
            out.add(line.toString());
        }
        return out;
    }

    private static int mix(int a, int b, float t) {
        int out = 0;
        for (int shift = 24; shift >= 0; shift -= 8) {
            int ca = (a >>> shift) & 0xFF;
            int cb = (b >>> shift) & 0xFF;
            out |= (Math.round(ca + (cb - ca) * t) & 0xFF) << shift;
        }
        return out;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        config.save();
        MinecraftClient.getInstance().setScreen(null);
    }
}
