package com.carthelper;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class CartHelperClient implements ClientModInitializer {
    // сколько тиков ждём ответ сервера
    private static final int GIVE_UP_TICKS = 20;

    private enum Wait { NONE, RAIL, CART }

    private Config config;
    private KeyBinding menuKey;
    private KeyBinding highlightKey;
    private KeyBinding autoKey;
    private final Auto auto = new Auto();

    private Wait wait = Wait.NONE;
    private BlockPos waitPos;
    private int waitAge;
    private int cartsBefore;

    // на каком шаге цепочки сейчас
    private int cur;
    private int lastArrow = -1;
    private boolean usePressed;
    private int ticks;

    @Override
    public void onInitializeClient() {
        config = Config.load();
        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("carthelper", "main"));
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.carthelper.menu", GLFW.GLFW_KEY_K, category));
        highlightKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.carthelper.highlight", GLFW.GLFW_KEY_H, category));
        autoKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.carthelper.auto", GLFW.GLFW_KEY_R, category));
        UseBlockCallback.EVENT.register(this::onUse);
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    // на одиночке этот колбэк зовётся и для сервера, поэтому проверка на ClientPlayerEntity
    private ActionResult onUse(PlayerEntity player, World world, Hand hand, BlockHitResult hit) {
        if (!(player instanceof ClientPlayerEntity) || hand != Hand.MAIN_HAND) {
            return ActionResult.PASS;
        }
        if (!config.enabled || !config.autoSwitch || auto.running()) {
            return ActionResult.PASS;
        }
        Item held = player.getStackInHand(hand).getItem();
        BlockPos clicked = hit.getBlockPos();
        BlockState state = world.getBlockState(clicked);
        if (held == Items.RAIL) {
            // по траве рельса встаёт на её место
            BlockPos at = state.isReplaceable() ? clicked : clicked.offset(hit.getSide());
            startWait(Wait.RAIL, at);
        } else if (held == Items.TNT_MINECART && state.isIn(BlockTags.RAILS)) {
            cartsBefore = countCarts(world, clicked);
            startWait(Wait.CART, clicked);
        }
        return ActionResult.PASS;
    }

    private void startWait(Wait what, BlockPos pos) {
        wait = what;
        waitPos = pos;
        waitAge = 0;
    }

    private void tick(MinecraftClient mc) {
        ClientPlayerEntity me = mc.player;
        if (me == null || mc.world == null) {
            wait = Wait.NONE;
            cur = 0;
            lastArrow = -1;
            usePressed = false;
            auto.off();
            return;
        }

        while (menuKey.wasPressed()) {
            mc.setScreen(new KartScreen(config));
        }
        while (highlightKey.wasPressed()) {
            config.highlight = !config.highlight;
            config.save();
            me.sendMessage(Text.translatable(config.highlight ? "carthelper.highlight.on" : "carthelper.highlight.off"), true);
        }

        while (autoKey.wasPressed()) {
            if (auto.running()) {
                auto.stop(mc, me, "Авто: отменено");
            } else if (config.enabled) {
                wait = Wait.NONE;
                auto.start(mc, me, config, autoSteps());
            }
        }

        if (auto.running()) {
            wait = Wait.NONE;
            auto.tick(mc, me);
        } else if (config.enabled && config.autoSwitch) {
            checkWait(mc, me);
            checkArrow(mc, me);
            checkFlint(mc, me);
        } else {
            wait = Wait.NONE;
        }

        if (config.enabled && config.highlight && mc.currentScreen == null && ++ticks % 3 == 0) {
            BlockPos spot = Highlight.find(mc, me, config);
            if (spot != null) {
                Highlight.show(mc.world, spot);
            }
        }
    }

    private void checkWait(MinecraftClient mc, ClientPlayerEntity me) {
        if (wait == Wait.NONE) {
            return;
        }
        if (++waitAge > GIVE_UP_TICKS) {
            wait = Wait.NONE;
            return;
        }
        if (wait == Wait.RAIL && mc.world.getBlockState(waitPos).isIn(BlockTags.RAILS)) {
            wait = Wait.NONE;
            advance(me, Pick.RAIL);
        } else if (wait == Wait.CART && countCarts(mc.world, waitPos) > cartsBefore) {
            wait = Wait.NONE;
            advance(me, Pick.TNT_MINECART);
        }
    }

    // выстрел = новая стрела с тобой как владельцем
    private void checkArrow(MinecraftClient mc, ClientPlayerEntity me) {
        Item held = me.getMainHandStack().getItem();
        if (held != Items.BOW && held != Items.CROSSBOW) {
            return;
        }
        List<PersistentProjectileEntity> arrows = mc.world.getEntitiesByClass(PersistentProjectileEntity.class,
                me.getBoundingBox().expand(6.0), a -> a.getOwner() == me && a.age <= 2);
        for (PersistentProjectileEntity arrow : arrows) {
            if (arrow.getId() != lastArrow) {
                lastArrow = arrow.getId();
                advance(me, held == Items.BOW ? Pick.BOW : Pick.CROSSBOW);
                return;
            }
        }
    }

    private void checkFlint(MinecraftClient mc, ClientPlayerEntity me) {
        boolean pressed = mc.options.useKey.isPressed();
        if (pressed && !usePressed && mc.currentScreen == null && me.getMainHandStack().isOf(Items.FLINT_AND_STEEL)) {
            advance(me, Pick.FLINT_AND_STEEL);
        }
        usePressed = pressed;
    }

    private void advance(ClientPlayerEntity me, Pick kind) {
        List<List<Pick>> steps = steps();
        int found = -1;
        for (int k = 0; k < steps.size() && found < 0; k++) {
            int i = (cur + k) % steps.size();
            if (steps.get(i).contains(kind)) {
                found = i;
            }
        }
        if (found < 0) {
            return;
        }
        // последний шаг такой же, как первый: это уже начало нового круга
        if (found > 0 && steps.get(found).equals(steps.get(0))) {
            found = 0;
        }
        cur = found + 1;
        // нет предмета в хотбаре, идём дальше
        while (cur < steps.size()) {
            if (select(me, steps.get(cur))) {
                return;
            }
            cur++;
        }
        // конец цепочки
        cur = 0;
    }

    // для авто: последний шаг, как у первого, не нужен (это просто начало нового круга)
    private List<List<Pick>> autoSteps() {
        List<List<Pick>> list = steps();
        if (list.size() > 1 && list.get(list.size() - 1).equals(list.get(0))) {
            list.remove(list.size() - 1);
        }
        return list;
    }

    // orPrev цепляет предмет к предыдущему шагу
    private List<List<Pick>> steps() {
        List<List<Pick>> out = new ArrayList<>();
        for (Config.Step s : config.sequence) {
            if (s.item == null) {
                continue;
            }
            if (s.orPrev && !out.isEmpty()) {
                out.get(out.size() - 1).add(s.item);
            } else {
                List<Pick> group = new ArrayList<>();
                group.add(s.item);
                out.add(group);
            }
        }
        return out;
    }

    private boolean select(ClientPlayerEntity me, List<Pick> group) {
        PlayerInventory inv = me.getInventory();
        for (Pick p : group) {
            for (int i = 0; i < 9; i++) {
                if (inv.getStack(i).isOf(p.item)) {
                    inv.setSelectedSlot(i);
                    return true;
                }
            }
        }
        return false;
    }

    private static int countCarts(World world, BlockPos pos) {
        return world.getOtherEntities(null, new Box(pos),
                e -> Registries.ENTITY_TYPE.getId(e.getType()).getPath().endsWith("minecart")).size();
    }
}
