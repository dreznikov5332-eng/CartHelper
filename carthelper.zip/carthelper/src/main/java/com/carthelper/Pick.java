package com.carthelper;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;

public enum Pick {
    RAIL(Items.RAIL, "Рельсы"),
    TNT_MINECART(Items.TNT_MINECART, "Вагонетка с TNT"),
    BOW(Items.BOW, "Лук"),
    CROSSBOW(Items.CROSSBOW, "Арбалет"),
    FLINT_AND_STEEL(Items.FLINT_AND_STEEL, "Огниво");

    public final Item item;
    private final String name;

    Pick(Item item, String name) {
        this.item = item;
        this.name = name;
    }

    public Text label() {
        return Text.literal(name);
    }

    public ItemStack stack() {
        return new ItemStack(item);
    }

    public Pick step(int dir) {
        Pick[] all = values();
        return all[Math.floorMod(ordinal() + dir, all.length)];
    }
}
