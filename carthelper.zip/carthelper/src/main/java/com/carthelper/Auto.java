package com.carthelper;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.List;

// всё само по кнопке: рельса, вагонетка, выстрел или огниво
final class Auto {
    // дольше этого не работаем (тики)
    private static final int LIMIT = 300;

    private boolean on;
    private List<List<Pick>> steps;
    private int step;
    private Pick now;
    private int phase;
    private int timer;
    private int total;

    private BlockPos spot;
    private Entity cart;
    private BlockPos fire;
    private int cartsBefore;

    boolean running() {
        return on;
    }

    void off() {
        on = false;
    }

    void start(MinecraftClient mc, ClientPlayerEntity me, Config cfg, List<List<Pick>> list) {
        spot = Highlight.find(mc, me, cfg);
        if (spot == null) {
            say(me, "Авто: нет подходящего места");
            return;
        }
        steps = list;
        step = 0;
        now = null;
        phase = 0;
        timer = 0;
        total = 0;
        cart = null;
        on = true;
        say(me, "Авто: поехали");
    }

    void stop(MinecraftClient mc, ClientPlayerEntity me, String why) {
        on = false;
        mc.options.useKey.setPressed(false);
        if (why != null) {
            say(me, why);
        }
    }

    void tick(MinecraftClient mc, ClientPlayerEntity me) {
        if (!on) {
            return;
        }
        if (mc.currentScreen != null || !me.isAlive() || ++total > LIMIT) {
            stop(mc, me, "Авто: остановлено");
            return;
        }
        if (step >= steps.size()) {
            stop(mc, me, "Авто: готово");
            return;
        }
        if (now == null) {
            // берём предмет, действие уже на следующем тике
            now = take(me, steps.get(step));
            if (now == null) {
                step++;
            }
            phase = 0;
            timer = 0;
            return;
        }
        switch (now) {
            case RAIL -> rail(mc, me);
            case TNT_MINECART -> minecart(mc, me);
            case BOW -> bow(mc, me);
            case CROSSBOW -> crossbow(mc, me);
            case FLINT_AND_STEEL -> flint(mc, me);
        }
    }

    private void next() {
        step++;
        now = null;
    }

    private Pick take(ClientPlayerEntity me, List<Pick> group) {
        PlayerInventory inv = me.getInventory();
        for (Pick p : group) {
            for (int i = 0; i < 9; i++) {
                if (inv.getStack(i).isOf(p.item)) {
                    inv.setSelectedSlot(i);
                    return p;
                }
            }
        }
        return null;
    }

    private void rail(MinecraftClient mc, ClientPlayerEntity me) {
        BlockPos cell = spot.up();
        if (mc.world.getBlockState(cell).isIn(BlockTags.RAILS)) {
            next();
            return;
        }
        if (phase == 0) {
            Vec3d top = new Vec3d(spot.getX() + 0.5, spot.getY() + 1.0, spot.getZ() + 0.5);
            click(mc, me, new BlockHitResult(top, Direction.UP, spot, false));
            phase = 1;
            timer = 0;
        } else if (++timer > 10) {
            stop(mc, me, "Авто: рельса не поставилась");
        }
    }

    private void minecart(MinecraftClient mc, ClientPlayerEntity me) {
        BlockPos cell = spot.up();
        if (!mc.world.getBlockState(cell).isIn(BlockTags.RAILS)) {
            stop(mc, me, "Авто: нет рельсы");
            return;
        }
        if (phase == 0) {
            cartsBefore = carts(mc, cell).size();
            click(mc, me, new BlockHitResult(Vec3d.ofCenter(cell), Direction.UP, cell, false));
            phase = 1;
            timer = 0;
            return;
        }
        List<Entity> found = carts(mc, cell);
        if (found.size() > cartsBefore) {
            cart = found.get(0);
            next();
        } else if (++timer > 10) {
            stop(mc, me, "Авто: вагонетка не поставилась");
        }
    }

    private void bow(MinecraftClient mc, ClientPlayerEntity me) {
        aim(me, true);
        if (phase == 0) {
            mc.options.useKey.setPressed(true);
            if (me.isUsingItem() && me.getItemUseTime() >= 20) {
                phase = 1;
            } else if (++timer > 60) {
                stop(mc, me, "Авто: нет стрел?");
            }
        } else if (phase == 1) {
            mc.options.useKey.setPressed(false);
            phase = 2;
            timer = 0;
        } else if (!me.isUsingItem() || ++timer > 5) {
            next();
        }
    }

    private void crossbow(MinecraftClient mc, ClientPlayerEntity me) {
        ItemStack stack = me.getMainHandStack();
        aim(me, true);
        if (phase == 0) {
            if (CrossbowItem.isCharged(stack)) {
                phase = 2;
            } else {
                mc.options.useKey.setPressed(true);
                phase = 1;
                timer = 0;
            }
        } else if (phase == 1) {
            if (CrossbowItem.isCharged(stack)) {
                mc.options.useKey.setPressed(false);
                phase = 2;
            } else if (++timer > 60) {
                stop(mc, me, "Авто: нет стрел?");
            }
        } else if (phase == 2) {
            // тик на поворот
            phase = 3;
        } else if (phase == 3) {
            mc.options.useKey.setPressed(true);
            phase = 4;
        } else {
            mc.options.useKey.setPressed(false);
            next();
        }
    }

    // огонь на блоке перед вагонеткой: стрела пролетит через него и загорится
    private void flint(MinecraftClient mc, ClientPlayerEntity me) {
        if (cart == null || !cart.isAlive()) {
            stop(mc, me, "Авто: нет вагонетки");
            return;
        }
        if (phase == 0) {
            fire = fireCell(mc, me);
            if (fire == null) {
                stop(mc, me, "Авто: перед вагонеткой негде поджечь");
                return;
            }
            BlockPos base = fire.down();
            Vec3d top = new Vec3d(base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5);
            click(mc, me, new BlockHitResult(top, Direction.UP, base, false));
            phase = 1;
            timer = 0;
        } else if (mc.world.getBlockState(fire).isIn(BlockTags.FIRE)) {
            next();
        } else if (++timer > 10) {
            stop(mc, me, "Авто: огонь не появился");
        }
    }

    // клетка на линии от тебя к вагонетке, сразу перед ней
    private BlockPos fireCell(MinecraftClient mc, ClientPlayerEntity me) {
        Vec3d c = cart.getBoundingBox().getCenter();
        Vec3d eye = me.getEyePos();
        double dx = eye.x - c.x;
        double dz = eye.z - c.z;
        double len = Math.hypot(dx, dz);
        if (len < 0.1) {
            return null;
        }
        BlockPos rail = spot.up();
        for (double d : new double[]{1.0, 1.5}) {
            BlockPos cell = BlockPos.ofFloored(c.x + dx / len * d, rail.getY(), c.z + dz / len * d);
            BlockPos base = cell.down();
            if (cell.equals(rail) || me.getBoundingBox().intersects(new Box(cell))) {
                continue;
            }
            BlockState state = mc.world.getBlockState(cell);
            boolean free = state.isAir() || state.isReplaceable();
            boolean solid = mc.world.getBlockState(base).isSideSolidFullSquare(mc.world, base, Direction.UP);
            Vec3d top = new Vec3d(base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5);
            if (free && solid && eye.distanceTo(top) <= 4.5) {
                return cell;
            }
        }
        return null;
    }

    private void click(MinecraftClient mc, ClientPlayerEntity me, BlockHitResult hit) {
        ActionResult r = mc.interactionManager.interactBlock(me, Hand.MAIN_HAND, hit);
        if (r.isAccepted()) {
            me.swingHand(Hand.MAIN_HAND);
        }
    }

    private List<Entity> carts(MinecraftClient mc, BlockPos cell) {
        return mc.world.getOtherEntities(null, new Box(cell).expand(1.0),
                e -> Registries.ENTITY_TYPE.getId(e.getType()).getPath().endsWith("minecart"));
    }

    // куда стрелять: в вагонетку, а если её ещё нет, то в клетку над рельсой
    private Vec3d point() {
        if (cart != null && cart.isAlive()) {
            return cart.getBoundingBox().getCenter();
        }
        return new Vec3d(spot.getX() + 0.5, spot.getY() + 1.3, spot.getZ() + 0.5);
    }

    private void aim(ClientPlayerEntity me, boolean arrow) {
        Vec3d from = me.getEyePos();
        Vec3d to = point();
        double dx = to.x - from.x;
        double dz = to.z - from.z;
        double dy = to.y - from.y;
        double flat = Math.hypot(dx, dz);
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
        float pitch = arrow ? pitchFor(flat, dy) : (float) -Math.toDegrees(Math.atan2(dy, flat));
        me.setYaw(yaw);
        me.setPitch(pitch);
    }

    // стрела летит по дуге: гоняем полёт по тикам и берём угол, который попадает ближе всего
    private static float pitchFor(double dist, double height) {
        float best = 0;
        double bestErr = 1e9;
        for (float pitch = -60; pitch <= 60; pitch += 0.25f) {
            double vh = Math.cos(Math.toRadians(pitch)) * 3.0;
            double vy = -Math.sin(Math.toRadians(pitch)) * 3.0;
            double h = 0;
            double y = 0;
            for (int t = 0; t < 80; t++) {
                h += vh;
                y += vy;
                vh *= 0.99;
                vy *= 0.99;
                vy -= 0.05;
                if (h >= dist) {
                    double err = Math.abs(y - height);
                    if (err < bestErr) {
                        bestErr = err;
                        best = pitch;
                    }
                    break;
                }
            }
        }
        return best;
    }

    private static void say(ClientPlayerEntity me, String text) {
        me.sendMessage(Text.literal(text), true);
    }
}
