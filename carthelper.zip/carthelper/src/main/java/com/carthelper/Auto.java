package com.carthelper;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.CrossbowItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

// всё само по кнопке: рельса, вагонетка, огонь, выстрел
final class Auto {
    // дольше этого не работаем (тики)
    private static final int LIMIT = 400;
    private static final double BOW_SPEED = 3.0;
    private static final double CROSSBOW_SPEED = 3.15;

    private boolean on;
    private List<List<Pick>> steps;
    private int step;
    private Pick now;
    private int phase;
    private int timer;
    private int total;
    private int waitFire;

    private BlockPos spot;
    private Entity cart;
    private BlockPos fire;
    private int cartsBefore;

    boolean running() {
        return on;
    }

    void off() {
        on = false;
    }

    void start(MinecraftClient mc, ClientPlayerEntity me, Config cfg, List<List<Pick>> list) {
        spot = Highlight.find(mc, me, cfg);
        if (spot == null) {
            say(me, "Авто: нет подходящего места");
            return;
        }
        steps = list;
        step = 0;
        now = null;
        phase = 0;
        timer = 0;
        total = 0;
        waitFire = 0;
        cart = null;
        fire = null;
        on = true;
        say(me, "Авто: поехали");
    }

    void stop(MinecraftClient mc, ClientPlayerEntity me, String why) {
        on = false;
        mc.options.useKey.setPressed(false);
        if (why != null) {
            say(me, why);
        }
    }

    void tick(MinecraftClient mc, ClientPlayerEntity me) {
        if (!on) {
            return;
        }
        if (mc.currentScreen != null || !me.isAlive() || ++total > LIMIT) {
            stop(mc, me, "Авто: остановлено");
            return;
        }
        if (step >= steps.size()) {
            stop(mc, me, "Авто: готово");
            return;
        }
        if (now == null) {
            // берём предмет, действие уже на следующем тике
            now = take(me, steps.get(step));
            if (now == null) {
                step++;
            }
            phase = 0;
            timer = 0;
            waitFire = 0;
            return;
        }
        switch (now) {
            case RAIL -> rail(mc, me);
            case TNT_MINECART -> minecart(mc, me);
            case BOW -> bow(mc, me);
            case CROSSBOW -> crossbow(mc, me);
            case FLINT_AND_STEEL -> flint(mc, me);
        }
    }

    private void next() {
        step++;
        now = null;
    }

    private Pick take(ClientPlayerEntity me, List<Pick> group) {
        PlayerInventory inv = me.getInventory();
        for (Pick p : group) {
            for (int i = 0; i < 9; i++) {
                if (inv.getStack(i).isOf(p.item)) {
                    inv.setSelectedSlot(i);
                    return p;
                }
            }
        }
        return null;
    }

    private void rail(MinecraftClient mc, ClientPlayerEntity me) {
        BlockPos cell = spot.up();
        if (mc.world.getBlockState(cell).isIn(BlockTags.RAILS)) {
            next();
            return;
        }
        if (phase == 0) {
            Vec3d top = new Vec3d(spot.getX() + 0.5, spot.getY() + 1.0, spot.getZ() + 0.5);
            click(mc, me, new BlockHitResult(top, Direction.UP, spot, false));
            phase = 1;
            timer = 0;
        } else if (++timer > 10) {
            stop(mc, me, "Авто: рельса не поставилась");
        }
    }

    private void minecart(MinecraftClient mc, ClientPlayerEntity me) {
        BlockPos cell = spot.up();
        if (!mc.world.getBlockState(cell).isIn(BlockTags.RAILS)) {
            stop(mc, me, "Авто: нет рельсы");
            return;
        }
        if (phase == 0) {
            cartsBefore = carts(mc, cell).size();
            click(mc, me, new BlockHitResult(Vec3d.ofCenter(cell), Direction.UP, cell, false));
            phase = 1;
            timer = 0;
            return;
        }
        List<Entity> found = carts(mc, cell);
        if (found.size() > cartsBefore) {
            cart = found.get(0);
            next();
        } else if (++timer > 10) {
            stop(mc, me, "Авто: вагонетка не поставилась");
        }
    }

    // огонь на блоке, через который потом пройдёт стрела
    private void flint(MinecraftClient mc, ClientPlayerEntity me) {
        if (cart == null || !cart.isAlive()) {
            stop(mc, me, "Авто: нет вагонетки");
            return;
        }
        if (phase == 0) {
            fire = fireCell(mc, me);
            if (fire == null) {
                stop(mc, me, "Авто: нет места для огня на линии выстрела");
                return;
            }
            if (mc.world.getBlockState(fire).isIn(BlockTags.FIRE)) {
                next();
                return;
            }
            BlockPos base = fire.down();
            Vec3d top = new Vec3d(base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5);
            click(mc, me, new BlockHitResult(top, Direction.UP, base, false));
            phase = 1;
            timer = 0;
        } else if (mc.world.getBlockState(fire).isIn(BlockTags.FIRE)) {
            next();
        } else if (++timer > 10) {
            stop(mc, me, "Авто: огонь не появился");
        }
    }

    private void bow(MinecraftClient mc, ClientPlayerEntity me) {
        aim(me, BOW_SPEED);
        if (phase == 0) {
            mc.options.useKey.setPressed(true);
            if (me.isUsingItem() && me.getItemUseTime() >= 20) {
                phase = 1;
            } else if (++timer > 60) {
                stop(mc, me, "Авто: нет стрел?");
            }
        } else if (phase == 1) {
            if (fireOk(mc, me, BOW_SPEED)) {
                mc.options.useKey.setPressed(false);
                phase = 2;
                timer = 0;
            }
        } else if (!me.isUsingItem() || ++timer > 5) {
            next();
        }
    }

    private void crossbow(MinecraftClient mc, ClientPlayerEntity me) {
        boolean charged = CrossbowItem.isCharged(me.getMainHandStack());
        aim(me, CROSSBOW_SPEED);
        if (phase == 0) {
            if (charged) {
                phase = 2;
            } else {
                mc.options.useKey.setPressed(true);
                phase = 1;
                timer = 0;
            }
        } else if (phase == 1) {
            if (charged) {
                mc.options.useKey.setPressed(false);
                phase = 2;
            } else if (++timer > 60) {
                stop(mc, me, "Авто: нет стрел?");
            }
        } else if (phase == 2) {
            // выстрел только если стрела идёт через огонь
            if (fireOk(mc, me, CROSSBOW_SPEED)) {
                phase = 3;
            }
        } else if (phase == 3) {
            mc.options.useKey.setPressed(true);
            phase = 4;
        } else {
            mc.options.useKey.setPressed(false);
            next();
        }
    }

    // true, когда можно стрелять: огонь горит и линия выстрела идёт через него
    private boolean fireOk(MinecraftClient mc, ClientPlayerEntity me, double speed) {
        if (fire == null) {
            return true;
        }
        if (!mc.world.getBlockState(fire).isIn(BlockTags.FIRE)) {
            stop(mc, me, "Авто: огонь погас");
            return false;
        }
        if (crosses(me, speed)) {
            return true;
        }
        if (++waitFire > 30) {
            stop(mc, me, "Авто: стрела не идёт через огонь, встань ровнее");
        }
        return false;
    }

    private void click(MinecraftClient mc, ClientPlayerEntity me, BlockHitResult hit) {
        ActionResult r = mc.interactionManager.interactBlock(me, Hand.MAIN_HAND, hit);
        if (r.isAccepted()) {
            me.swingHand(Hand.MAIN_HAND);
        }
    }

    private List<Entity> carts(MinecraftClient mc, BlockPos cell) {
        return mc.world.getOtherEntities(null, new Box(cell).expand(1.0),
                e -> Registries.ENTITY_TYPE.getId(e.getType()).getPath().endsWith("minecart"));
    }

    // куда стрелять: в вагонетку, а если её ещё нет, то в клетку над рельсой
    private Vec3d point() {
        if (cart != null && cart.isAlive()) {
            return cart.getBoundingBox().getCenter();
        }
        return new Vec3d(spot.getX() + 0.5, spot.getY() + 1.3, spot.getZ() + 0.5);
    }

    private void aim(ClientPlayerEntity me, double speed) {
        Vec3d eye = me.getEyePos();
        Vec3d to = point();
        me.setYaw(yawTo(eye, to));
        me.setPitch(pitchTo(eye, to, speed));
    }

    private static float yawTo(Vec3d from, Vec3d to) {
        return (float) Math.toDegrees(Math.atan2(to.z - from.z, to.x - from.x)) - 90.0f;
    }

    private static float pitchTo(Vec3d from, Vec3d to, double speed) {
        double dist = Math.hypot(to.x - from.x, to.z - from.z);
        // стрела вылетает чуть ниже глаз
        double height = to.y - (from.y - 0.1);
        float best = 0;
        double bestErr = 1e9;
        for (float pitch = -60; pitch <= 60; pitch += 0.25f) {
            double vh = Math.cos(Math.toRadians(pitch)) * speed;
            double vy = -Math.sin(Math.toRadians(pitch)) * speed;
            double h = 0;
            double y = 0;
            for (int t = 0; t < 100; t++) {
                h += vh;
                y += vy;
                vh *= 0.99;
                vy *= 0.99;
                vy -= 0.05;
                if (h >= dist) {
                    double err = Math.abs(y - height);
                    if (err < bestErr) {
                        bestErr = err;
                        best = pitch;
                    }
                    break;
                }
            }
        }
        return best;
    }

    // путь стрелы точками (по 10 на тик) до вагонетки, как в игре: сначала сдвиг, потом сопротивление и гравитация
    private static List<Vec3d> flight(Vec3d eye, float yaw, float pitch, double speed, Vec3d target) {
        double yr = Math.toRadians(yaw);
        double pr = Math.toRadians(pitch);
        double vx = -Math.sin(yr) * Math.cos(pr) * speed;
        double vy = -Math.sin(pr) * speed;
        double vz = Math.cos(yr) * Math.cos(pr) * speed;
        Vec3d p = eye.add(0, -0.1, 0);
        List<Vec3d> out = new ArrayList<>();
        for (int t = 0; t < 100; t++) {
            for (int k = 1; k <= 10; k++) {
                Vec3d q = p.add(vx * k / 10.0, vy * k / 10.0, vz * k / 10.0);
                out.add(q);
                if (q.distanceTo(target) < 0.5) {
                    return out;
                }
            }
            p = p.add(vx, vy, vz);
            vx *= 0.99;
            vy *= 0.99;
            vz *= 0.99;
            vy -= 0.05;
        }
        return out;
    }

    // идёт ли стрела через огонь при нынешнем повороте
    private boolean crosses(ClientPlayerEntity me, double speed) {
        Box box = new Box(fire).expand(0.05);
        for (Vec3d q : flight(me.getEyePos(), me.getYaw(), me.getPitch(), speed, point())) {
            if (box.contains(q)) {
                return true;
            }
        }
        return false;
    }

    // клетка для огня: берём путь стрелы и идём по нему от вагонетки назад к тебе
    private BlockPos fireCell(MinecraftClient mc, ClientPlayerEntity me) {
        Vec3d eye = me.getEyePos();
        Vec3d target = point();
        List<Vec3d> path = flight(eye, yawTo(eye, target), pitchTo(eye, target, CROSSBOW_SPEED), CROSSBOW_SPEED, target);
        BlockPos rail = spot.up();
        Set<BlockPos> seen = new HashSet<>();
        for (int i = path.size() - 1; i >= 0; i--) {
            Vec3d q = path.get(i);
            if (q.distanceTo(target) < 0.9) {
                continue;
            }
            BlockPos cell = BlockPos.ofFloored(q);
            if (cell.equals(rail) || !seen.add(cell)) {
                continue;
            }
            if (mc.world.getBlockState(cell).isIn(BlockTags.FIRE)) {
                return cell;
            }
            BlockPos base = cell.down();
            BlockState state = mc.world.getBlockState(cell);
            boolean free = (state.isAir() || state.isReplaceable()) && mc.world.getFluidState(cell).isEmpty();
            boolean solid = mc.world.getBlockState(base).isSideSolidFullSquare(mc.world, base, Direction.UP);
            Vec3d top = new Vec3d(base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5);
            boolean inside = me.getBoundingBox().intersects(new Box(cell));
            if (free && solid && !inside && eye.distanceTo(top) <= 4.5) {
                return cell;
            }
        }
        return null;
    }

    private static void say(ClientPlayerEntity me, String text) {
        me.sendMessage(Text.literal(text), true);
    }
}
