package com.carthelper;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.CrossbowItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

// всё само по кнопке: рельса, вагонетка и огонь в один тик, потом выстрел
final class Auto {
    // дольше этого не работаем (тики)
    private static final int LIMIT = 400;
    private static final double BOW_SPEED = 3.0;
    private static final double CROSSBOW_SPEED = 3.15;
    // внутренняя фаза зарядки: ждём, пока арбалет зарядится после отпускания
    private static final int LOAD_WAIT = 6;

    private Config cfg;
    private boolean on;
    private boolean preload;
    private List<List<Pick>> steps;
    private int step;
    private Pick now;
    private int phase;
    private int timer;
    private int total;
    private int waitFire;
    private int watch;

    private BlockPos spot;
    private Entity cart;
    private boolean cartPlaced;
    private BlockPos fire;

    boolean running() {
        return on;
    }

    void off() {
        on = false;
    }

    void start(MinecraftClient mc, ClientPlayerEntity me, Config config, List<List<Pick>> list) {
        cfg = config;
        spot = Highlight.find(mc, me, cfg);
        if (spot == null) {
            say(me, "Авто: нет подходящего места");
            return;
        }
        steps = list;
        step = 0;
        now = null;
        phase = 0;
        timer = 0;
        total = 0;
        waitFire = 0;
        cart = null;
        cartPlaced = false;
        fire = null;
        on = true;
        // арбалет заряжаем заранее, если он ещё не заряжен
        preload = false;
        if (has(list, Pick.CROSSBOW) && take(me, List.of(Pick.CROSSBOW)) != null) {
            preload = !CrossbowItem.isCharged(me.getMainHandStack());
        }
        log("старт, я " + v(me.getEyePos()) + ", враг " + enemy() + ", место " + spot + ", цепочка " + list);
    }

    void stop(MinecraftClient mc, ClientPlayerEntity me, String why) {
        on = false;
        preload = false;
        mc.options.useKey.setPressed(false);
        log("стоп: " + why);
        if (why != null) {
            say(me, why);
        }
    }

    void tick(MinecraftClient mc, ClientPlayerEntity me) {
        if (!on) {
            return;
        }
        if (mc.currentScreen != null || !me.isAlive() || ++total > LIMIT) {
            stop(mc, me, "Авто: остановлено");
            return;
        }
        findCart(mc);
        if (preload) {
            if (load(mc, me)) {
                preload = false;
                phase = 0;
                timer = 0;
                log("арбалет заряжен");
            }
            return;
        }
        if (step >= steps.size()) {
            stop(mc, me, "Авто: готово");
            return;
        }
        if (now == null) {
            // всё, что можно сделать мгновенно, делаем сразу
            if (rush(mc, me) || !on) {
                return;
            }
            if (step >= steps.size()) {
                return;
            }
            now = take(me, steps.get(step));
            if (now == null) {
                step++;
            } else {
                log("шаг " + now);
            }
            phase = 0;
            timer = 0;
            waitFire = 0;
            return;
        }
        switch (now) {
            case BOW -> bow(mc, me);
            case CROSSBOW -> crossbow(mc, me);
            default -> next();
        }
    }

    // после выстрела пишем в лог, куда летит стрела
    void watch(MinecraftClient mc, ClientPlayerEntity me) {
        if (watch <= 0 || mc.world == null) {
            return;
        }
        watch--;
        List<PersistentProjectileEntity> arrows = mc.world.getEntitiesByClass(PersistentProjectileEntity.class,
                me.getBoundingBox().expand(40.0), a -> a.getOwner() == me);
        for (PersistentProjectileEntity a : arrows) {
            Vec3d p = new Vec3d(a.getX(), a.getY(), a.getZ());
            log("стрела " + v(p) + " скорость " + v(a.getVelocity()) + " горит " + a.isOnFire()
                    + " до вагонетки " + String.format(Locale.ROOT, "%.2f", p.distanceTo(point())));
        }
        if (cart != null && !cart.isAlive()) {
            log("вагонетки уже нет, враг " + enemy());
            watch = 0;
        }
    }

    private void next() {
        step++;
        now = null;
    }

    private static boolean has(List<List<Pick>> list, Pick p) {
        for (List<Pick> group : list) {
            if (group.contains(p)) {
                return true;
            }
        }
        return false;
    }

    private Pick take(ClientPlayerEntity me, List<Pick> group) {
        PlayerInventory inv = me.getInventory();
        for (Pick p : group) {
            for (int i = 0; i < 9; i++) {
                if (inv.getStack(i).isOf(p.item)) {
                    inv.setSelectedSlot(i);
                    return p;
                }
            }
        }
        return null;
    }

    // вагонетка появляется у нас в мире не сразу, ловим её, как только она есть
    private void findCart(MinecraftClient mc) {
        if (!cartPlaced || (cart != null && cart.isAlive())) {
            return;
        }
        List<Entity> list = carts(mc, spot.up());
        if (!list.isEmpty()) {
            cart = list.get(0);
            log("вагонетка в мире " + v(point()));
        }
    }

    // рельса, вагонетка и огонь идут подряд за один тик; true = в этот тик что-то сделано
    private boolean rush(MinecraftClient mc, ClientPlayerEntity me) {
        boolean did = false;
        while (step < steps.size()) {
            Pick p = take(me, steps.get(step));
            if (p == null) {
                step++;
                continue;
            }
            if (p == Pick.BOW) {
                return did;
            }
            if (p == Pick.CROSSBOW) {
                if (!CrossbowItem.isCharged(me.getMainHandStack())) {
                    return did;
                }
                // повернулись сейчас, выстрел на следующем тике
                now = p;
                phase = 2;
                timer = 0;
                waitFire = 0;
                aim(me, CROSSBOW_SPEED);
                log("шаг CROSSBOW, заряжен");
                return true;
            }
            boolean ok = switch (p) {
                case RAIL -> placeRail(mc, me);
                case TNT_MINECART -> placeCart(mc, me);
                default -> placeFire(mc, me);
            };
            if (!ok) {
                return true;
            }
            did = true;
            step++;
        }
        return did;
    }

    private boolean placeRail(MinecraftClient mc, ClientPlayerEntity me) {
        // место берём заново, враг мог сдвинуться
        BlockPos fresh = Highlight.find(mc, me, cfg);
        if (fresh != null) {
            spot = fresh;
        }
        BlockPos cell = spot.up();
        if (mc.world.getBlockState(cell).isIn(BlockTags.RAILS)) {
            return true;
        }
        Vec3d top = new Vec3d(spot.getX() + 0.5, spot.getY() + 1.0, spot.getZ() + 0.5);
        ActionResult r = click(mc, me, new BlockHitResult(top, Direction.UP, spot, false));
        log("рельса на " + spot + ", враг " + enemy() + ", ответ " + r);
        if (!r.isAccepted()) {
            stop(mc, me, "Авто: рельса не поставилась");
            return false;
        }
        return true;
    }

    private boolean placeCart(MinecraftClient mc, ClientPlayerEntity me) {
        BlockPos cell = spot.up();
        if (!mc.world.getBlockState(cell).isIn(BlockTags.RAILS)) {
            stop(mc, me, "Авто: нет рельсы");
            return false;
        }
        ActionResult r = click(mc, me, new BlockHitResult(Vec3d.ofCenter(cell), Direction.UP, cell, false));
        log("вагонетка, ответ " + r);
        if (!r.isAccepted()) {
            stop(mc, me, "Авто: вагонетка не поставилась");
            return false;
        }
        cartPlaced = true;
        return true;
    }

    // огонь на блоке, через который потом пройдёт стрела
    private boolean placeFire(MinecraftClient mc, ClientPlayerEntity me) {
        fire = fireCell(mc, me);
        if (fire == null) {
            stop(mc, me, "Авто: нет места для огня на линии выстрела");
            return false;
        }
        log("огонь на " + fire);
        if (mc.world.getBlockState(fire).isIn(BlockTags.FIRE)) {
            return true;
        }
        BlockPos base = fire.down();
        Vec3d top = new Vec3d(base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5);
        click(mc, me, new BlockHitResult(top, Direction.UP, base, false));
        return true;
    }

    private void bow(MinecraftClient mc, ClientPlayerEntity me) {
        aim(me, BOW_SPEED);
        if (phase == 0) {
            mc.options.useKey.setPressed(true);
            if (me.isUsingItem() && me.getItemUseTime() >= 20) {
                phase = 1;
            } else if (++timer > 60) {
                stop(mc, me, "Авто: нет стрел?");
            }
        } else if (phase == 1) {
            if (fireOk(mc, me, BOW_SPEED)) {
                mc.options.useKey.setPressed(false);
                shot(me);
                phase = 2;
                timer = 0;
            }
        } else if (!me.isUsingItem() || ++timer > 5) {
            next();
        }
    }

    private void crossbow(MinecraftClient mc, ClientPlayerEntity me) {
        aim(me, CROSSBOW_SPEED);
        if (phase < 2 || phase == LOAD_WAIT) {
            if (load(mc, me)) {
                phase = 2;
            }
        } else if (phase == 2) {
            if (timer++ < cfg.autoDelay) {
                return;
            }
            if (fireOk(mc, me, CROSSBOW_SPEED)) {
                ActionResult r = mc.interactionManager.interactItem(me, Hand.MAIN_HAND);
                if (r.isAccepted()) {
                    me.swingHand(Hand.MAIN_HAND);
                }
                shot(me);
                phase = 3;
            }
        } else {
            next();
        }
    }

    // арбалет заряжается, когда кнопку отпустили после полной натяжки; true = заряжен
    private boolean load(MinecraftClient mc, ClientPlayerEntity me) {
        if (CrossbowItem.isCharged(me.getMainHandStack())) {
            mc.options.useKey.setPressed(false);
            return true;
        }
        if (phase == 0) {
            mc.options.useKey.setPressed(true);
            if (me.isUsingItem()) {
                phase = 1;
            } else if (++timer > 20) {
                stop(mc, me, "Авто: арбалет не заряжается, есть стрелы?");
            }
        } else if (phase == 1) {
            // у арбалета макс. время использования на 3 тика больше времени натяжки
            if (!me.isUsingItem()) {
                phase = 0;
            } else if (me.getItemUseTimeLeft() <= 3) {
                mc.options.useKey.setPressed(false);
                phase = LOAD_WAIT;
                timer = 0;
            }
        } else if (++timer > 20) {
            stop(mc, me, "Авто: арбалет не зарядился");
        }
        return false;
    }

    // можно ли стрелять: огонь горит, линия идёт через него; если не идёт, ждём пару тиков и стреляем всё равно
    private boolean fireOk(MinecraftClient mc, ClientPlayerEntity me, double speed) {
        if (fire == null) {
            return true;
        }
        if (!mc.world.getBlockState(fire).isIn(BlockTags.FIRE)) {
            stop(mc, me, "Авто: огонь погас");
            return false;
        }
        if (crosses(me, speed)) {
            return true;
        }
        if (++waitFire > 3) {
            log("линия мимо огня, стреляю всё равно");
            return true;
        }
        return false;
    }

    private void shot(ClientPlayerEntity me) {
        watch = 60;
        log("выстрел: я " + v(me.getEyePos()) + " yaw " + String.format(Locale.ROOT, "%.1f", me.getYaw())
                + " pitch " + String.format(Locale.ROOT, "%.1f", me.getPitch()) + " цель " + v(point())
                + " враг " + enemy());
    }

    private ActionResult click(MinecraftClient mc, ClientPlayerEntity me, BlockHitResult hit) {
        ActionResult r = mc.interactionManager.interactBlock(me, Hand.MAIN_HAND, hit);
        if (r.isAccepted()) {
            me.swingHand(Hand.MAIN_HAND);
        }
        return r;
    }

    private List<Entity> carts(MinecraftClient mc, BlockPos cell) {
        return mc.world.getOtherEntities(null, new Box(cell).expand(1.0),
                e -> Registries.ENTITY_TYPE.getId(e.getType()).getPath().endsWith("minecart"));
    }

    // куда стрелять: в вагонетку, а пока её нет, в место, где она встанет
    private Vec3d point() {
        if (cart != null && cart.isAlive()) {
            return cart.getBoundingBox().getCenter();
        }
        return new Vec3d(spot.getX() + 0.5, spot.getY() + 1.41, spot.getZ() + 0.5);
    }

    private void aim(ClientPlayerEntity me, double speed) {
        Vec3d eye = me.getEyePos();
        Vec3d to = point();
        me.setYaw(yawTo(eye, to));
        me.setPitch(pitchTo(eye, to, speed));
    }

    private static float yawTo(Vec3d from, Vec3d to) {
        return (float) Math.toDegrees(Math.atan2(to.z - from.z, to.x - from.x)) - 90.0f;
    }

    // угол вниз (плюс = вниз), при котором стрела придёт в точку; полёт считаем кусками по 0.1 тика
    private static float pitchTo(Vec3d from, Vec3d to, double speed) {
        double dist = Math.hypot(to.x - from.x, to.z - from.z);
        // стрела вылетает чуть ниже глаз
        double height = to.y - (from.y - 0.1);
        float best = 0;
        double bestErr = 1e9;
        // только прямой выстрел, без навесных дуг
        for (float pitch = -45; pitch <= 89; pitch += 0.1f) {
            double vh = Math.cos(Math.toRadians(pitch)) * speed;
            double vy = -Math.sin(Math.toRadians(pitch)) * speed;
            double h = 0;
            double y = 0;
            boolean got = false;
            for (int t = 0; t < 100 && !got; t++) {
                double prevH = h;
                double prevY = y;
                for (int k = 1; k <= 10; k++) {
                    double hh = h + vh * k / 10.0;
                    double yy = y + vy * k / 10.0;
                    if (hh >= dist) {
                        double f = (dist - prevH) / (hh - prevH);
                        double err = Math.abs(prevY + f * (yy - prevY) - height);
                        if (err < bestErr) {
                            bestErr = err;
                            best = pitch;
                        }
                        got = true;
                        break;
                    }
                    prevH = hh;
                    prevY = yy;
                }
                h += vh;
                y += vy;
                vh *= 0.99;
                vy *= 0.99;
                vy -= 0.05;
            }
        }
        return best;
    }

    // путь стрелы точками (по 10 на тик) до вагонетки, как в игре: сначала сдвиг, потом сопротивление и гравитация
    private static List<Vec3d> flight(Vec3d eye, float yaw, float pitch, double speed, Vec3d target) {
        double yr = Math.toRadians(yaw);
        double pr = Math.toRadians(pitch);
        double vx = -Math.sin(yr) * Math.cos(pr) * speed;
        double vy = -Math.sin(pr) * speed;
        double vz = Math.cos(yr) * Math.cos(pr) * speed;
        Vec3d p = eye.add(0, -0.1, 0);
        List<Vec3d> out = new ArrayList<>();
        for (int t = 0; t < 100; t++) {
            for (int k = 1; k <= 10; k++) {
                Vec3d q = p.add(vx * k / 10.0, vy * k / 10.0, vz * k / 10.0);
                out.add(q);
                if (q.distanceTo(target) < 0.5) {
                    return out;
                }
            }
            p = p.add(vx, vy, vz);
            vx *= 0.99;
            vy *= 0.99;
            vz *= 0.99;
            vy -= 0.05;
        }
        return out;
    }

    // идёт ли стрела через огонь при нынешнем повороте
    private boolean crosses(ClientPlayerEntity me, double speed) {
        Box box = new Box(fire).expand(0.05);
        for (Vec3d q : flight(me.getEyePos(), me.getYaw(), me.getPitch(), speed, point())) {
            if (box.contains(q)) {
                return true;
            }
        }
        return false;
    }

    // клетка для огня: берём путь стрелы и идём по нему от вагонетки назад к тебе
    private BlockPos fireCell(MinecraftClient mc, ClientPlayerEntity me) {
        Vec3d eye = me.getEyePos();
        Vec3d target = point();
        List<Vec3d> path = flight(eye, yawTo(eye, target), pitchTo(eye, target, CROSSBOW_SPEED), CROSSBOW_SPEED, target);
        BlockPos rail = spot.up();
        Set<BlockPos> seen = new HashSet<>();
        for (int i = path.size() - 1; i >= 0; i--) {
            Vec3d q = path.get(i);
            if (q.distanceTo(target) < 0.9) {
                continue;
            }
            BlockPos cell = BlockPos.ofFloored(q);
            if (cell.equals(rail) || !seen.add(cell)) {
                continue;
            }
            if (mc.world.getBlockState(cell).isIn(BlockTags.FIRE)) {
                return cell;
            }
            BlockPos base = cell.down();
            BlockState state = mc.world.getBlockState(cell);
            boolean free = (state.isAir() || state.isReplaceable()) && mc.world.getFluidState(cell).isEmpty();
            boolean solid = mc.world.getBlockState(base).isSideSolidFullSquare(mc.world, base, Direction.UP);
            Vec3d top = new Vec3d(base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5);
            boolean inside = me.getBoundingBox().intersects(new Box(cell));
            if (free && solid && !inside && eye.distanceTo(top) <= 4.5) {
                return cell;
            }
        }
        return null;
    }

    private static String enemy() {
        Entity t = Highlight.lastTarget;
        return t == null ? "?" : v(new Vec3d(t.getX(), t.getY(), t.getZ()));
    }

    private static String v(Vec3d p) {
        return String.format(Locale.ROOT, "(%.2f %.2f %.2f)", p.x, p.y, p.z);
    }

    private void log(String text) {
        System.out.println("[CartHelper] t" + total + " " + text);
    }

    private static void say(ClientPlayerEntity me, String text) {
        me.sendMessage(Text.literal(text), true);
    }
}
